Place `build-core-lite-prod.yml` at:

```text
.github/workflows/build-core-lite-prod.yml
```

This v002 workflow generates and tests the core-lite-prod operational substrate,
then uploads a zipped generated file bundle:

```text
core-lite-prod-generated-v001.zip
core-lite-prod-generated-v001-manifest.json
```
